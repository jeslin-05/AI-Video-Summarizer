import { useState } from "react";
import axios from "axios";
import "./index.css";

const languages = [
  { label: "English (Default)", value: "en" },
  { label: "Tamil", value: "ta" },
  { label: "Hindi", value: "hi" },
  { label: "Telugu", value: "te" },
  { label: "Malayalam", value: "ml" },
  { label: "Kannada", value: "kn" },
  { label: "Sanskrit", value: "sa" },
  { label: "Spanish", value: "es" }, // Added Spanish
  { label: "French", value: "fr" }    // Added French
];

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [view, setView] = useState("login");
  const [theme, setTheme] = useState("dark");
  const [authData, setAuthData] = useState({ username: "", password: "", rePassword: "", mobile: "" });
  
  const [url, setUrl] = useState("");
  const [summary, setSummary] = useState("");
  const [displaySummary, setDisplaySummary] = useState("");
  const [detectedLang, setDetectedLang] = useState("");
  const [loading, setLoading] = useState(false);

  const resetAppData = () => {
    setSummary("");
    setDisplaySummary("");
    setUrl("");
    setDetectedLang("");
  };

  const handleLogout = () => {
    resetAppData();
    setIsLoggedIn(false);
    setView("login");
  };

  const handleAuth = async () => {
    try {
      if (view === "signup") {
        if (authData.password !== authData.rePassword) return alert("Passwords do not match!");
        await axios.post("http://127.0.0.1:8000/signup", {
          username: authData.username,
          password: authData.password,
          mobile: authData.mobile
        });
        alert("Registered successfully! Please login.");
        setView("login");
      } else {
        const res = await axios.post("http://127.0.0.1:8000/login", {
          username: authData.username,
          password: authData.password
        });
        if (res.data.status === "success") {
          resetAppData(); 
          setIsLoggedIn(true);
        }
      }
    } catch (err) {
      alert(err.response?.data?.detail || "Authentication Failed");
    }
  };

  const handleSummarize = async () => {
    if (!url) return alert("Please enter a YouTube link.");
    setLoading(true);
    setSummary(""); // Clear previous before starting
    try {
      const res = await axios.post("http://127.0.0.1:8000/summarize", { url });
      if (res.data.status === "success") {
        setSummary(res.data.summary);
        setDisplaySummary(res.data.summary);
        setDetectedLang(res.data.detected_language);
      } else {
        alert("Error: " + res.data.message);
      }
    } catch (err) {
      alert("Summarization failed. Check server logs.");
    }
    setLoading(false);
  };

  const handleLanguageChange = async (lang) => {
    if (lang === "en") { setDisplaySummary(summary); return; }
    try {
      const res = await axios.post("http://127.0.0.1:8000/translate", { 
        text: summary, 
        target_lang: lang 
      });
      setDisplaySummary(res.data.translated_text);
    } catch (err) {
      alert("Translation error.");
    }
  };

  const exportFile = async (type) => {
    const res = await axios.post(`http://127.0.0.1:8000/export/${type}`, 
      { text: displaySummary, target_lang: "en" }, 
      { responseType: "blob" }
    );
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(new Blob([res.data]));
    link.download = `summary.${type === "pdf" ? "pdf" : "docx"}`;
    link.click();
  };

  return (
    <div className={`app-container ${theme} animate-fade`}>
      <div className="top-nav">
        <button className="theme-btn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
          {theme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode"}
        </button>
        {isLoggedIn && <button className="logout-btn" onClick={handleLogout}>Logout</button>}
      </div>

      {!isLoggedIn ? (
        <div className="glass-card auth-card animate-slide-up">
          <h2 className="auth-title">{view === "login" ? "Login" : "Sign Up"}</h2>
          <div className="input-stack">
            <input type="text" placeholder="Username" style={{padding: '22px 20px'}} 
              onChange={(e) => setAuthData({...authData, username: e.target.value})} />
            <input type="password" placeholder="Password" style={{padding: '22px 20px'}} 
              onChange={(e) => setAuthData({...authData, password: e.target.value})} />
            {view === "signup" && (
              <>
                <input type="password" placeholder="Confirm Password" style={{padding: '22px 20px'}} 
                  onChange={(e) => setAuthData({...authData, rePassword: e.target.value})} />
                <input type="text" placeholder="Mobile Number" style={{padding: '22px 20px'}} 
                  onChange={(e) => setAuthData({...authData, mobile: e.target.value})} />
              </>
            )}
          </div>
          <div style={{textAlign: 'left', width: '100%', marginTop: '24px'}}>
            <button className="primary-btn" onClick={handleAuth}>
              {view === "login" ? "Login" : "Sign Up"}
            </button>
          </div>
          <p className="auth-footer" onClick={() => {setView(view === "login" ? "signup" : "login"); resetAppData();}}>
            {view === "login" ? "Need an account? Sign Up" : "Already have an account? Login"}
          </p>
        </div>
      ) : (
        <div className="animate-fade" style={{width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <h1 className="main-logo">🎥 AI Video Summarizer</h1>
          
          {!summary ? (
            <div className="glass-card main-card animate-slide-up">
              <p className="description">Paste a YouTube link for a crisp AI summary.</p>
              <div className="input-stack">
                <input type="text" placeholder="YouTube Link..." style={{padding: '24px 20px'}} 
                  value={url} onChange={(e) => setUrl(e.target.value)} />
                <div style={{textAlign: 'center', marginTop: '15px'}}>
                  <button className="primary-btn" style={{padding: '20px 50px'}} onClick={handleSummarize} disabled={loading}>
                    {loading ? "Processing..." : "Summarize"}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="glass-card result-card animate-slide-up">
              <div className="result-header">
                <div className="badge">Detected: {detectedLang.toUpperCase()}</div>
                <select className="language-dropdown" onChange={(e) => handleLanguageChange(e.target.value)}>
                  {languages.map((l) => (<option key={l.value} value={l.value}>{l.label}</option>))}
                </select>
              </div>
              <div className="summary-display">{displaySummary}</div>
              <div className="action-row">
                <button className="export-btn pdf" onClick={() => exportFile("pdf")}>📄 PDF</button>
                <button className="export-btn word" onClick={() => exportFile("doc")}>📝 Word</button>
                <button className="back-btn-small" onClick={() => setSummary("")}>🔙 Back</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;